﻿using UnityEngine;
using System.Collections;

public class PowerUpWeaponGrenade : PowerUp
{

	protected override void Start() {

		PowerUpName = "Grenades";

	}

	public override void Give()
	{
		
//		Player.Current.DNU_Grenade = true;
//
//		base.Give ();

	}

}