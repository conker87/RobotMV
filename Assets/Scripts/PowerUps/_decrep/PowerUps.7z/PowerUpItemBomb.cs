﻿using UnityEngine;
using System.Collections;

public class PowerUpItemBomb : PowerUp {

	int bombsGiven = 3;

	protected override void Start() {

		PowerUpName = "Bomb";

	}

	public override void Give()
	{

		Player.Current.BombsCount = Player.Current.BombsMaximum = bombsGiven;

		base.Give ();

	}

}
